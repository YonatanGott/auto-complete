export interface IEmployee {
    name: string;
    workTitle: string;
    imageUrl: string;
}